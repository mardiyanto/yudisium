  <ul class="sidebar-menu">
  <li>
              <a href='index.php?aksi=home'>
                <i class='fa fa-dashboard'></i> <span>Dashboard</span> 
              </a> 
 </li>
 <li>      
      <a href="index.php?aksi=profil">
                  <i class="fa fa-briefcase"></i> <span>PROFIL</span>
                </a>
              </li>
<li class='treeview'>
               <a href='#'>
                 <i class='fa fa-bank'></i>
                 <span>MASTER DATA</span>
               </a>
               <ul class='treeview-menu'>
                <li><a href='index.php?aksi=mhs'><i class='fa fa-arrows-h'></i> MAHASISWA</a></li>
               </ul>
</li>

      <li>      
      <a href="logout.php">
                  <i class="fa fa-sign-out"></i> <span>LOGOUT</span>
                </a>
              </li>
</ul>